"""
Simple chatbot implementation for initial testing.
This version works without LangGraph for basic functionality testing.
"""

from typing import List, Dict, Any
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, BaseMessage
from langchain.tools.render import render_text_description
from config import Config
from tools import AVAILABLE_TOOLS

class SimpleChatbot:
    """A simple chatbot implementation for initial testing."""
    
    def __init__(self, model_name: str = None, debug: bool = True):
        """Initialize the simple chatbot."""
        self.debug = debug
        self.model_name = model_name or Config.DEFAULT_MODEL
        self.tools = AVAILABLE_TOOLS
        
        if self.debug:
            print(f"🤖 [DEBUG] Initializing Simple Chatbot...")
            print(f"🤖 [DEBUG] Model: {self.model_name}")
            print(f"🤖 [DEBUG] Available tools: {[tool.name for tool in self.tools]}")
        
        # Initialize the LLM
        self.llm = ChatOpenAI(
            model=self.model_name,
            temperature=Config.TEMPERATURE,
            max_tokens=Config.MAX_TOKENS,
            openai_api_key=Config.OPENAI_API_KEY
        )
        
        # Create tools description for the prompt
        self.tools_description = render_text_description(self.tools)
        
        if self.debug:
            print(f"🤖 [DEBUG] Simple Chatbot ready! 🚀\n")
    
    def chat(self, message: str, conversation_history: List[BaseMessage] = None) -> str:
        """
        Send a message to the chatbot and get a response.
        
        Args:
            message: The user's message
            conversation_history: Previous conversation messages
            
        Returns:
            The chatbot's response
        """
        if self.debug:
            print(f"\n💬 [DEBUG] ===== SIMPLE CHAT SESSION =====")
            print(f"💬 [DEBUG] User message: {message}")
        
        # Prepare the system prompt with tools information
        system_prompt = f"""You are a helpful AI assistant. You have access to the following tools:

{self.tools_description}

When you need to use a tool, respond with the tool name and its input in this format:
TOOL: tool_name
INPUT: tool_input

Otherwise, respond normally to the user's message.
"""
        
        # Prepare messages
        messages = [HumanMessage(content=system_prompt)]
        
        # Add conversation history
        if conversation_history:
            messages.extend(conversation_history)
            if self.debug:
                print(f"💬 [DEBUG] Added {len(conversation_history)} history messages")
        
        # Add current message
        messages.append(HumanMessage(content=message))
        
        if self.debug:
            print(f"💬 [DEBUG] Total messages: {len(messages)}")
            print(f"🧠 [DEBUG] Calling LLM...")
        
        # Get response from LLM
        response = self.llm.invoke(messages)
        response_content = response.content
        
        if self.debug:
            print(f"🧠 [DEBUG] LLM response: {response_content[:100]}...")
        
        # Check if the response contains a tool call
        if "TOOL:" in response_content and "INPUT:" in response_content:
            if self.debug:
                print(f"🛠️  [DEBUG] Tool call detected in response")
            
            try:
                # Parse tool call
                lines = response_content.strip().split('\n')
                tool_name = None
                tool_input = None
                
                for line in lines:
                    if line.startswith("TOOL:"):
                        tool_name = line.replace("TOOL:", "").strip()
                    elif line.startswith("INPUT:"):
                        tool_input = line.replace("INPUT:", "").strip()
                
                if tool_name and tool_input:
                    if self.debug:
                        print(f"🛠️  [DEBUG] Parsed tool call - Name: {tool_name}, Input: {tool_input}")
                    
                    # Execute the tool
                    tool_result = self._execute_tool(tool_name, tool_input)
                    
                    if self.debug:
                        print(f"💬 [DEBUG] ===== SIMPLE CHAT SESSION END =====\n")
                    
                    return tool_result
                    
            except Exception as e:
                if self.debug:
                    print(f"❌ [DEBUG] Error parsing tool call: {e}")
                return f"Error executing tool: {e}"
        
        if self.debug:
            print(f"💬 [DEBUG] ===== SIMPLE CHAT SESSION END =====\n")
        
        return response_content
    
    def _execute_tool(self, tool_name: str, tool_input: str) -> str:
        """Execute a tool by name."""
        if self.debug:
            print(f"🛠️  [DEBUG] Executing tool: {tool_name}")
            print(f"🛠️  [DEBUG] Tool input: {tool_input}")
        
        for tool in self.tools:
            if tool.name == tool_name:
                try:
                    result = tool.invoke(tool_input)
                    if self.debug:
                        print(f"✅ [DEBUG] Tool execution successful!")
                        print(f"✅ [DEBUG] Tool result: {str(result)[:200]}...")
                    return str(result)
                except Exception as e:
                    error_msg = f"Error using {tool_name}: {e}"
                    if self.debug:
                        print(f"❌ [DEBUG] Tool execution failed: {e}")
                    return error_msg
        
        error_msg = f"Tool '{tool_name}' not found. Available tools: {[t.name for t in self.tools]}"
        if self.debug:
            print(f"❌ [DEBUG] {error_msg}")
        return error_msg

# Convenience function
def create_simple_chatbot(debug: bool = True) -> SimpleChatbot:
    """Create a simple chatbot instance."""
    return SimpleChatbot(debug=debug)

# Example usage
if __name__ == "__main__":
    print("Simple Chatbot initialized!")
    print("Available tools:", [tool.name for tool in AVAILABLE_TOOLS])
    print("\nType 'quit' to exit\n")
    
    chatbot = create_simple_chatbot()
    conversation_history = []
    
    while True:
        user_input = input("You: ")
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("Goodbye!")
            break
        
        try:
            response = chatbot.chat(user_input, conversation_history)
            print(f"Bot: {response}\n")
            
            # Update conversation history
            conversation_history.extend([
                HumanMessage(content=user_input),
                AIMessage(content=response)
            ])
            
        except Exception as e:
            print(f"Error: {e}")
            print("Please make sure you have set your OPENAI_API_KEY in the .env file\n")
