# LangGraph Chatbot POC

## Overview
This project demonstrates how to build a chatbot using LangGraph, showcasing different conversation patterns and state management capabilities.

## Features
- Basic conversational chatbot
- Memory management with conversation history
- Tool integration (calculator, weather info)
- Different conversation flows
- Streamlit web interface

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Create a `.env` file and add your OpenAI API key:
```
MY_PERSONAL_AZURE_OPENAI_API_KEY=your_api_key_here
```

## Run the application 
- Choose either of the following commands in project root directory based on your preference or environment setup. 

**Option A:**
```bash
streamlit run app.py
```

**Option B:**
```bash
python -m streamlit run app.py
```

## Project Structure
- `chatbot.py` - Core LangGraph chatbot implementation
- `tools.py` - Custom tools for the chatbot
- `app.py` - Streamlit web interface
- `examples/` - Example usage scripts
- `config.py` - Configuration settings

## Examples
- `examples/basic_chat.py` - Simple conversation example
- `examples/tool_usage.py` - Chatbot with tool integration
- `examples/memory_demo.py` - Conversation memory demonstration
