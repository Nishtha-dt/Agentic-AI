"""
Quick test to verify the chatbot fix works correctly.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from simple_chatbot import create_simple_chatbot

def test_chatbot():
    """Test the simple chatbot to make sure it works."""
    print("🧪 Testing the simple chatbot...")
    
    try:
        chatbot = create_simple_chatbot()
        print("✅ Chatbot initialized successfully!")
        
        # Test basic conversation
        response = chatbot.chat("Hello!")
        print(f"✅ Basic chat works: {response[:100]}...")
        
        # Test tool usage
        response = chatbot.chat("What is 5 + 3?")
        print(f"✅ Calculator tool works: {response[:100]}...")
        
        print("🎉 All tests passed! The chatbot is working correctly.")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        print("Make sure your OpenAI API key is set in the .env file")
        return False

if __name__ == "__main__":
    test_chatbot()
