import __main__
from typing import Dict, Any
from langchain.tools import tool
import requests
import json
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
from myutil import CalculatorInput,CalculatorOutput, get_llm

# Load environment variables
load_dotenv()



#method to get network status using the fuseki # API which is a SPARQL server
def get_network_status(query:str) -> str:
    """
    Gets the network status from a SPARQL server.
    
    Returns:
        Network status as a string
    """

    #Read TTL file form file system
    with open("ontology/network-topology-ontology.ttl", "r") as file:
        ttl_content = file.read()


    print(f"🛠️ [DEBUG] Loaded TTL content: {ttl_content[:100]}...")  # Print the first 100 characters for brevity



    system_prompt=f"""

    You are an expert Semantic Web and Ontology assistant. You will be provided with the contents of a .TTL (Turtle) RDF ontology file. Your tasks are:

    1. Understand the Ontology: Analyze the classes, properties, and relationships defined in the Turtle file.
    2. Answer Queries: When a user requests a SPARQL query for specific information or relationships within the ontology, generate a precise SPARQL query based on the ontology structure.
    3. Explain Reasoning: Briefly explain how you constructed each SPARQL query if asked.
    4. Output: Return only the SPARQL query. 
    5. Query should be valid and executable against the SPARQL endpoint. It should include all necessary prefixes.
    6. Response must be only the query nothing else in it so that it can be executed directly.

    Example SPARQL:    

    System:
    You are an expert Semantic Web and Ontology assistant. You will be provided with the contents of a .TTL (Turtle) RDF ontology file. Your tasks are: ... [as above]
    TTL:  Network ontology ttl is {ttl_content}

    User:
    Please write a SPARQL query to list all instances of the class.

    """
    
    llm=get_llm("gpt4")


    messages = [{"role": "system", "content": system_prompt}]

    messages.append({"role": "user", "content": query})

    response = llm.invoke(messages)

    #print(f"🛠️ [DEBUG] LLM response: {response}")

    sparql_query = response.content.strip();

    print(f"🛠️ [DEBUG] Generated SPARQL query: {sparql_query}")

    sparql_endpoint = os.getenv("SPARQL_ENDPOINT", " http://localhost:3030/network-topology/sparql")
    
    print(f"🛠️ [DEBUG] Fetching network status from {sparql_endpoint}")
    try:
        print(f"🛠️ [DEBUG] Executing SPARQL query: {sparql_query}")
        response = requests.get(sparql_endpoint, params={'query': sparql_query, 'format': 'application/sparql-results+json'})
        print(f"🛠️ [DEBUG] Response status code: {response}")
        data = response.json()
        print(f"🛠️ [DEBUG] Response from SPARQL server: {json.dumps(data, indent=2)}")
        # if data['results']['bindings']:
        #     status = data['results']['bindings'][0]['label']['value']
        #     print(f"🛠️ [DEBUG] Network status fetched: {status}")
        #     return f"Network status: {status}"
        # else:
        #     return "No network status availabldatae."
    except requests.RequestException as e:
        return f"Error fetching network status: {str(e)}"
    
    return json.dumps(data, indent=2)
    

def calculator(input: CalculatorInput) -> CalculatorOutput:
    """
    Evaluates a mathematical expression safely.  
   
    Args:
        expression: A mathematical expression to evaluate (e.g., "2 + 2", "10 * 5")
        
    Returns:
        The result of the calculation as a string
    """
    try:
        print(f"🧮 [DEBUG] Evaluating expression: {input['expression']}")
        # For safety, only allow basic mathematical operations
        allowed_chars = set('0123456789+-*/.() ')
        if not all(c in allowed_chars for c in input["expression"]):
            return "Error: Only basic mathematical operations are allowed"

        result1 = eval(input["expression"])
        print(f"🧮 [DEBUG] Result: {result1}")
        # Return the result as a CalculatorOutput object
        return CalculatorOutput(result=str(result1), description=f"The result of {input['expression']} is {result1}")
    except Exception as e:
        return f"Error calculating {input['expression']}: {str(e)}"


def get_weather(city: str) -> str:
    """
    Gets current weather information for a city.
    Note: This is a mock implementation for demo purposes.
    
    Args:
        city: The name of the city to get weather for
    
    Returns:
        Weather information as a string
    """
    # Mock weather data for demonstration
    mock_weather = {
        "new york": "Sunny, 22°C (72°F), Light breeze",
        "london": "Cloudy, 15°C (59°F), Light rain expected",
        "tokyo": "Partly cloudy, 18°C (64°F), Humid",
        "paris": "Overcast, 16°C (61°F), Windy",
        "sydney": "Sunny, 25°C (77°F), Clear skies"
    }
    
    city_lower = city.lower()
    if city_lower in mock_weather:
        return f"Weather in {city}: {mock_weather[city_lower]}"
    else:
        return f"Weather information not available for {city}. Available cities: New York, London, Tokyo, Paris, Sydney"


def search_web(query: str) -> str:
    """
    Performs a web search (mock implementation for demo).
    
    Args:
        query: The search query
    
    Returns:
        Mock search results
    """
    return f"Mock search results for '{query}': Here are some relevant articles and information about {query}. This is a demonstration of tool integration with LangGraph."


# List of available tools
AVAILABLE_TOOLS = [calculator, get_weather, search_web, get_network_status]


if __name__ == "__main__":
    query = """
            PREFIX owl: <http://www.w3.org/2002/07/owl#>
            PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

            SELECT DISTINCT ?class ?label ?description
            WHERE {
            ?class a owl:Class.
            OPTIONAL { ?class rdfs:label ?label}
            OPTIONAL { ?class rdfs:comment ?description}
            }
            LIMIT 25            
            """
    get_network_status("Fetch the router status")

