import streamlit as st
from chatbot import LangGraphChatbot
from langchain.schema import HumanMessage, AIMessage
import traceback

# Page configuration
st.set_page_config(
    page_title="LangGraph Chatbot POC",
    page_icon="🤖",
    layout="wide"
)

# Initialize session state
if "chatbot" not in st.session_state:
    try:
        st.session_state.chatbot = LangGraphChatbot(debug=True)
        st.session_state.messages = []
        st.session_state.conversation_history = []
        st.session_state.debug_enabled = True
    except Exception as e:
        st.error(f"Failed to initialize chatbot: {e}")
        st.error("Please make sure you have set your OPENAI_API_KEY in the .env file")
        st.stop()

# Title and description
st.title("LangGraph poc")
st.markdown("### A demonstration of LangGraph-powered conversational AI")

# Sidebar with information
with st.sidebar:
    st.header("About")
    
    # st.image("output.png", caption="LangGraph Workflow Diagram", use_column_width=True)
    
    # # Save the image to a file
    # img_data = st.session_state.chatbot.graph.get_graph().draw_mermaid_png()
    # with open("output.png", "wb") as f:
    #     f.write(img_data)
    # print("Image saved as output.png. Open it to view.")
    
    st.header("Debug Controls")
    debug_enabled = st.checkbox("Enable Debug Output", value=st.session_state.get("debug_enabled", True))
    if debug_enabled != st.session_state.get("debug_enabled", True):
        st.session_state.debug_enabled = debug_enabled
        st.session_state.chatbot.set_debug(debug_enabled)
        st.rerun()
    
    if st.button("Show Debug Info"):
        debug_info = st.session_state.chatbot.get_debug_info()
        st.json(debug_info)
    
    st.header("Available Tools")
    st.markdown("""
    - 🧮 **Calculator**: Perform mathematical calculations
    - 🌤️ **Weather**: Get weather information for cities
    - 🔍 **Web Search**: Search for information (mock)
    """)
    
    st.header("Example Queries")
    st.markdown("""
    - "What's 15 * 24?"
    - "What's the weather like in Tokyo?"
    - "Search for information about LangGraph"
    """)
    
    if st.button("Clear Conversation"):
        st.session_state.messages = []
        st.session_state.conversation_history = []
        st.rerun()

# Main chat interface
st.header("Chat")

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("What would you like to know?"):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Get bot response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                response = st.session_state.chatbot.chat(
                    prompt, 
                    st.session_state.conversation_history
                )
                st.markdown(response)
                
                # Add to session state
                st.session_state.messages.append({"role": "assistant", "content": response})
                
                # Update conversation history
                st.session_state.conversation_history.extend([
                    HumanMessage(content=prompt),
                    AIMessage(content=response)
                ])
                
            except Exception as e:
                error_msg = f"Sorry, I encountered an error: {str(e)}"
                st.error(error_msg)
                st.session_state.messages.append({"role": "assistant", "content": error_msg})
                
                # Show detailed error in expander
                with st.expander("Error Details"):
                    st.code(traceback.format_exc())


