"""
Setup script for the LangGraph Chatbot POC project.
Run this script to set up the environment and install dependencies.
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors."""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed!")
        print(f"Error: {e.stderr}")
        return False

def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required!")
        return False
    print(f"✅ Python {sys.version} is compatible")
    return True

def create_env_file():
    """Create .env file if it doesn't exist."""
    env_file = Path(".env")
    env_example = Path(".env.example")
    
    if not env_file.exists() and env_example.exists():
        print("📝 Creating .env file from template...")
        with open(env_example, 'r') as src, open(env_file, 'w') as dst:
            dst.write(src.read())
        print("✅ .env file created! Please add your API keys.")
        return True
    elif env_file.exists():
        print("✅ .env file already exists")
        return True
    else:
        print("⚠️  No .env.example found, creating minimal .env...")
        with open(env_file, 'w') as f:
            f.write("OPENAI_API_KEY=your_openai_api_key_here\n")
        print("✅ Basic .env file created! Please add your OpenAI API key.")
        return True

def main():
    print("🚀 Setting up LangGraph Chatbot POC...")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Create virtual environment
    if not run_command("python -m venv venv", "Creating virtual environment"):
        print("⚠️  Failed to create virtual environment, continuing with global Python...")
    
    # Determine activation command based on OS
    if os.name == 'nt':  # Windows
        pip_command = "venv\\Scripts\\pip"
        python_command = "venv\\Scripts\\python"
        activate_command = "venv\\Scripts\\activate"
    else:  # Unix/Linux/MacOS
        pip_command = "venv/bin/pip"
        python_command = "venv/bin/python"
        activate_command = "source venv/bin/activate"
    
    # Install requirements
    if not run_command(f"{pip_command} install --upgrade pip", "Upgrading pip"):
        pip_command = "pip"  # Fallback to global pip
    
    if not run_command(f"{pip_command} install -r requirements.txt", "Installing dependencies"):
        print("❌ Failed to install dependencies!")
        sys.exit(1)
    
    # Create .env file
    create_env_file()
    
    print("\n🎉 Setup completed successfully!")
    print("=" * 50)
    print("Next steps:")
    print("1. Edit the .env file and add your OpenAI API key")
    print("2. Run one of the examples:")
    print("   - python examples/basic_chat.py")
    print("   - python examples/tool_usage.py")
    print("   - python examples/memory_demo.py")
    print("3. Or start the Streamlit web app:")
    print("   - streamlit run app.py")
    
    if os.name == 'nt':
        print(f"\n💡 To activate the virtual environment: {activate_command}")
    else:
        print(f"\n💡 To activate the virtual environment: {activate_command}")

if __name__ == "__main__":
    main()
