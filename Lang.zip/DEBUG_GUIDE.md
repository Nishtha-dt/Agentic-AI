# 🐛 LangGraph Chatbot Debug Guide

This guide explains how to use the debugging features added to your LangGraph chatbot.

## 🔧 Debug Features Added

### 1. **Comprehensive Debug Output**
The chatbot now provides detailed logging of:
- Initialization process
- Tool discovery and binding
- LLM calls and responses
- Tool execution details
- Workflow state transitions
- Error handling

### 2. **Debug Controls**
- Enable/disable debug mode on the fly
- Get debug information about the chatbot state
- Toggle debugging in Streamlit interface

## 📋 What You'll See in Debug Mode

### 🤖 **Initialization Debug**
```
🤖 [DEBUG] Initializing LangGraph Chatbot...
🤖 [DEBUG] Model: gpt-3.5-turbo
🤖 [DEBUG] Available tools: ['calculator', 'get_weather', 'search_web']
🤖 [DEBUG] LLM initialized successfully
🤖 [DEBUG] Tools bound to LLM: 3 tools
🔧 [DEBUG] Creating LangGraph workflow...
🔧 [DEBUG] Added nodes: agent, action
🔧 [DEBUG] Workflow edges configured
🤖 [DEBUG] LangGraph workflow created successfully
🤖 [DEBUG] Chatbot ready! 🚀
```

### 💬 **Chat Session Debug**
```
💬 [DEBUG] ===== NEW CHAT SESSION =====
💬 [DEBUG] User message: What is 15 * 8?
💬 [DEBUG] Conversation history length: 0
💬 [DEBUG] Total messages to process: 1
🚀 [DEBUG] Starting LangGraph workflow execution...
```

### 🧠 **LLM Processing Debug**
```
🧠 [DEBUG] Calling LLM with 1 messages
🧠 [DEBUG] Last message: What is 15 * 8?...
🧠 [DEBUG] LLM response received
🔧 [DEBUG] LLM wants to call tool: calculator
🔧 [DEBUG] Tool arguments: {"expression": "15 * 8"}
```

### 🛠️ **Tool Execution Debug**
```
🛠️  [DEBUG] Executing tool...
🛠️  [DEBUG] Tool name: calculator
🛠️  [DEBUG] Raw arguments: {"expression": "15 * 8"}
🛠️  [DEBUG] Parsed arguments (JSON): {'expression': '15 * 8'}
🛠️  [DEBUG] Found tool: calculator
🛠️  [DEBUG] Executing tool with input: {'expression': '15 * 8'}
✅ [DEBUG] Tool execution successful!
✅ [DEBUG] Tool response: The result of 15 * 8 is 120...
📤 [DEBUG] Sending tool result back to LLM
📤 [DEBUG] Function message created for: calculator
```

### 🔄 **Workflow Control Debug**
```
🔄 [DEBUG] Found function call, continuing to tool execution
🏁 [DEBUG] No function call found, ending workflow
```

### 🎯 **Final Response Debug**
```
✅ [DEBUG] LangGraph workflow completed
✅ [DEBUG] Total messages in result: 3
🎯 [DEBUG] Final AI response: The result of 15 * 8 is 120.
💬 [DEBUG] ===== CHAT SESSION END =====
```

## 🎮 How to Use Debug Features

### 1. **Command Line Interface**
```python
from chatbot import create_simple_chatbot

# Create chatbot with debugging enabled (default)
chatbot = create_simple_chatbot(debug=True)

# Or disable debugging
chatbot = create_simple_chatbot(debug=False)

# Toggle debug mode
chatbot.set_debug(True)   # Enable
chatbot.set_debug(False)  # Disable

# Get debug information
debug_info = chatbot.get_debug_info()
print(debug_info)
```

### 2. **Streamlit Web Interface**
- **Debug Toggle**: Use the checkbox in the sidebar to enable/disable debug output
- **Debug Info Button**: Click "Show Debug Info" to see current chatbot state
- **Console Output**: Debug messages appear in the terminal where you started Streamlit

### 3. **Test Scripts**
Run the debug test script to see all debug output:
```bash
python debug_test.py
```

## 🧪 Example Debug Sessions

### **Simple Conversation**
Input: "Hello! How are you?"
- Shows LLM processing
- No tool calls
- Direct response

### **Calculator Tool Usage**
Input: "What is 25 * 4?"
- Shows tool detection
- Calculator tool execution
- Result processing

### **Weather Tool Usage**
Input: "What's the weather in Tokyo?"
- Shows weather tool call
- Mock data retrieval
- Response formatting

### **Error Handling**
Input: "Calculate xyz * abc"
- Shows invalid input handling
- Error message generation
- Graceful failure

## 🎯 Debug Output Symbols

| Symbol | Meaning |
|--------|---------|
| 🤖 | Chatbot initialization |
| 🔧 | Workflow/graph operations |
| 💬 | Chat session management |
| 🧠 | LLM processing |
| 🛠️ | Tool operations |
| 🔄 | Workflow control |
| 📤 | Message passing |
| ✅ | Success operations |
| ❌ | Error conditions |
| 🎯 | Final results |
| 🚀 | Start operations |
| 🏁 | End operations |

## 💡 Tips for Debugging

1. **Enable Debug Mode**: Always start with debug mode enabled when developing
2. **Watch Tool Calls**: Pay attention to tool name and arguments
3. **Check Parsing**: Verify JSON parsing of tool arguments
4. **Monitor Workflow**: Follow the agent -> action -> agent flow
5. **Error Tracking**: Look for ❌ symbols to identify issues

## 🔍 Troubleshooting with Debug

### **Tool Not Found**
Look for:
```
❌ [DEBUG] Tool 'wrong_name' not found in available tools
❌ [DEBUG] Available tools: ['calculator', 'get_weather', 'search_web']
```

### **Argument Parsing Issues**
Look for:
```
🛠️  [DEBUG] Raw arguments: invalid_json
❌ [DEBUG] Tool execution failed: JSONDecodeError
```

### **LLM Connection Issues**
Look for:
```
❌ [DEBUG] Error: Connection error
```

This debug system will help you understand exactly what's happening in your chatbot and quickly identify any issues! 🚀
