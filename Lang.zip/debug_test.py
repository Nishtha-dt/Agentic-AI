"""
Debug test for the LangGraph chatbot.
This will show you all the debug output.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from chatbot import create_simple_chatbot

def test_debug_chatbot():
    """Test the chatbot with debug output enabled."""
    print("🧪 Testing LangGraph Chatbot with Debug Output")
    print("=" * 60)
    
    # Create chatbot with debugging enabled
    chatbot = create_simple_chatbot(debug=True)
    
    # Test cases
    test_cases = [
        "Hello! How are you?",
        "What is 15 * 8?",
        "What's the weather like in London?",
        "Search for information about Python"
    ]
    
    for i, test_message in enumerate(test_cases, 1):
        print(f"\n🧪 TEST {i}: {test_message}")
        print("-" * 40)
        
        try:
            response = chatbot.chat(test_message)
            print(f"🎯 FINAL RESPONSE: {response}")
        except Exception as e:
            print(f"❌ ERROR: {e}")
        
        print("-" * 40)
        input("Press Enter to continue to next test...")

if __name__ == "__main__":
    test_debug_chatbot()
