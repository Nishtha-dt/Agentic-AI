from pyexpat.errors import messages
from typing import TypedDict, List, Dict, Any, Annotated
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, BaseMessage
from langchain.tools.render import render_text_description
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.utils.function_calling import convert_to_openai_function
from myutil import get_llm
from IPython.display import Image, display
import operator
import logging
import json
from datetime import datetime
from config import Config
from tools import AVAILABLE_TOOLS
from langchain_core.runnables import RunnableLambda
from langgraph.prebuilt import create_react_agent
from pydantic import BaseModel
from myutil import CalculatorInput,CalculatorOutput


# Configure logging for debugging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Define the state structure
class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]




class WeatherInput(BaseModel):
    city: str
    

class LangGraphChatbot:
    def __init__(self, model_name: str = None, tools: List = None, debug: bool = True):
        """
        Initialize the LangGraph chatbot.
        
        Args:
            model_name: The LLM model to use
            tools: List of tools to make available to the chatbot
            debug: Enable debug output
        """
        self.debug = debug
        self.model_name = model_name or Config.DEFAULT_MODEL

        #self.tools = tools or AVAILABLE_TOOLS
        
        if self.debug:
            print(f"🤖 [DEBUG] Initializing LangGraph Chatbot...")
            print(f"🤖 [DEBUG] AVAILABLE_TOOLS: {AVAILABLE_TOOLS}")
            print(f"🤖 [DEBUG] Model: {self.model_name}")
            #print(f"🤖 [DEBUG] Available tools: {[tool.name for tool in self.tools]}")
        
        # Initialize the LLM
        self.llm = get_llm("gpt5")
        
        if self.debug:
            print(f"🤖 [DEBUG] LLM initialized successfully")
        
        # Bind tools to the LLM
        #print(f"🤖 [DEBUG] Binding tool: {AVAILABLE_TOOLS[0].name}")

        


        runnable1 = RunnableLambda(AVAILABLE_TOOLS[0]).with_types(input_type=CalculatorInput, output_type=CalculatorOutput)
        tool1 = runnable1.as_tool(
            name="calculator",
            description="""Performs a mathematical calculation.

            Args:
            expression: A mathematical expression to evaluate (e.g., "2 + 2", "10 * 5")
            description: A brief description of the calculation being performed

            Returns:
            The result of the calculation as a string
            """
        )

        print(f"🤖 [DEBUG] Invoking calculator tool with example input")
        result = tool1.invoke({
            'expression': '2 + 3 * (4 - 1)',
            'description': 'Calculate the result of a simple arithmetic expression'
        })
        print(f"🤖 [DEBUG] Calculator tool result: {result}")



        runnable2 = RunnableLambda(AVAILABLE_TOOLS[1])

        tool2 = runnable2.as_tool(
            name="get_weather",
            description="""Gets current weather information for a city.
                           
                            Note: This is a mock implementation for demo purposes.
                            
                            Args:
                                city: The name of the city to get weather for                            
                            Returns:
                                Weather information as a string
                            """      
        )



        
        

        runnable3 = RunnableLambda(AVAILABLE_TOOLS[2])
        tool3 = runnable3.as_tool(
            name="search_web",
            description="""Performs a web search (mock implementation for demo).
            
            Args:
                query: The search query
            
            Returns:
                Mock search results
            """
        ) 

        runnable4 = RunnableLambda(AVAILABLE_TOOLS[3])
        tool4 = runnable4.as_tool(
            name="get_network_status",
            description="""Gets the current network status including if routers, links, switches, etc. are working fine in the network.

            Args:
                query: The human message

            Returns:
                The network status as a string
            """
       )
        
        

        
        
        # Suppose you have a list of runnable tools
        tools = [tool1, tool2, tool3, tool4]  # Each is a RunnableLambda.as_tool(...)

        self.tools = tools
        
        # Convert each tool to OpenAI function format
        openai_functions = [convert_to_openai_function(tool) for tool in tools]

        # Bind to the LLM
        self.llm_with_tools = self.llm.bind(functions=openai_functions)
                
        if self.debug:
            print(f"🤖 [DEBUG] Tools bound to LLM: {len(self.tools)} tools")
        
        # Create the graph
        self.graph = self._create_graph()
        #display(Image(self.graph.get_graph().draw_mermaid_png()))
        
        if self.debug:
            print(f"🤖 [DEBUG] LangGraph workflow created successfully")
            print(f"🤖 [DEBUG] Chatbot ready! 🚀\n")
    
    def set_debug(self, debug: bool):
        """Enable or disable debug mode."""
        self.debug = debug
        if debug:
            print("🐛 [DEBUG] Debug mode enabled")
        else:
            print("🐛 [DEBUG] Debug mode disabled")
    
    def get_debug_info(self) -> Dict[str, Any]:
        """Get current debug information."""
        return {
            "debug_enabled": self.debug,
            "model_name": self.model_name,
            "available_tools": [tool.name for tool in self.tools],
            "tool_count": len(self.tools)
        }
    
    def _create_graph(self) -> StateGraph:
        """Create the LangGraph workflow."""
        if self.debug:
            print(f"🔧 [DEBUG] Creating LangGraph workflow...")
        
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("agent", self._call_model)
        workflow.add_node("action", self._call_tool)
        workflow.add_node("evaluator", self._evaluate_response)
        
        if self.debug:
            print(f"🔧 [DEBUG] Added nodes: agent, action")
        
        # Set entry point
        workflow.set_entry_point("agent")
        
        # Add edges
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "continue": "action",
                "end": "evaluator"
            }
        )

        # Conditional edge from evaluator
        workflow.add_conditional_edges(
            "evaluator",
            self._is_acceptable,
            {
                "acceptable": END,
                "not_acceptable": END
            }
        )
        
        workflow.add_edge("action", "agent")
        
        if self.debug:
            print(f"🔧 [DEBUG] Workflow edges configured")
        
        return workflow.compile()
    
    def _call_model(self, state: AgentState) -> Dict[str, Any]:
        """Call the LLM with the current state."""
        #print(f"🤖 [DEBUG] Calling LLM with state: {state}")
        messages = state["messages"]
        
        if self.debug:
            print(f"🧠 [DEBUG] Calling LLM with {len(messages)} messages")
            print(f"🧠 [DEBUG] Last message: {messages[-1].content[:100]}...")
            

        response = self.llm_with_tools.invoke(messages)
        
        if self.debug:
            print(f"🧠 [DEBUG] LLM response received")            
            if hasattr(response, 'additional_kwargs') and "function_call" in response.additional_kwargs:
                function_call = response.additional_kwargs["function_call"]
                print(f"🔧 [DEBUG] LLM wants to call tool: {function_call['name']}")
                print(f"🔧 [DEBUG] Tool arguments: {function_call['arguments']}")
            else:
                print(f"🧠 [DEBUG] LLM response: {response.content[:100]}...")
        
        return {"messages": [response]}
    
    def _call_tool(self, state: AgentState) -> Dict[str, Any]:
        """Execute the tool called by the LLM."""
        messages = state["messages"]
        last_message = messages[-1]
        
        if self.debug:
            print(f"🛠️  [DEBUG] Executing tool...")
        
        # Execute the tool
        tool_call = last_message.additional_kwargs["function_call"]
        
        # Find and execute the tool
        tool_name = tool_call["name"]
        
        if self.debug:
            print(f"🛠️  [DEBUG] Tool name: {tool_name}")
            print(f"🛠️  [DEBUG] Raw arguments: {tool_call['arguments']}")
        
        # Safely parse the arguments
        try:
            tool_input = json.loads(tool_call["arguments"])
            if self.debug:
                print(f"🛠️  [DEBUG] Parsed arguments (JSON): {tool_input}")
        except (json.JSONDecodeError, KeyError):
            try:
                tool_input = eval(tool_call["arguments"])
                if self.debug:
                    print(f"🛠️  [DEBUG] Parsed arguments (eval): {tool_input}")
            except:
                tool_input = tool_call["arguments"]
                if self.debug:
                    print(f"🛠️  [DEBUG] Using raw arguments: {tool_input}")
        
        # Execute the tool directly
        tool_response = None
        tool_found = False
        

        for tool in self.tools:
            if tool.name == tool_name:
                tool_found = True
                if self.debug:
                    print(f"🛠️  [DEBUG] Found tool: {tool_name}")
                    print(f"🛠️  [DEBUG] Executing tool with input: {tool_input}")                    
                try:                   
                    tool_response = tool.invoke(tool_input)                
                except Exception as e:
                    tool_response = f"Error executing {tool_name}: {str(e)}"
                    if self.debug:
                        print(f"❌ [DEBUG] Tool execution failed: {str(e)}")
                break
        
        if not tool_found:
            tool_response = f"Error: Tool '{tool_name}' not found"
            if self.debug:
                print(f"❌ [DEBUG] Tool '{tool_name}' not found in available tools")
                print(f"❌ [DEBUG] Available tools: {[t.name for t in self.tools]}")
        
        # Create a function message with the tool result
        from langchain.schema import FunctionMessage
        function_message = FunctionMessage(
            name=tool_call["name"],
            content=str(tool_response)
        )

        print(f"📤 [DEBUG] Tool response: {tool_response}")
        if self.debug:
            print(f"📤 [DEBUG] Sending tool result back to LLM")
            print(f"📤 [DEBUG] Function message created for: {function_message}")
            print(f"📤 [DEBUG] Function message created for: {tool_call['name']}")
           
        
        return {"messages": [function_message]}
    
    def _should_continue(self, state: AgentState) -> str:
        """Determine whether to continue or end the conversation."""
        messages = state["messages"]
        last_message = messages[-1]
        
        # If there's a function call, continue to execute the tool
        if hasattr(last_message, 'additional_kwargs') and "function_call" in last_message.additional_kwargs:
            if self.debug:
                print(f"🔄 [DEBUG] Found function call, continuing to tool execution")
            return "continue"
        else:
            if self.debug:
                print(f"🏁 [DEBUG] No function call found, ending workflow")
            return "end"
        
    def _evaluate_response(self, state: AgentState) -> Dict[str, Any]:
        """Ask LLM if the last response is acceptable."""
        messages = state["messages"]
        last_llm_response = state["messages"][-1].content

        # Find the last HumanMessage
        last_human_message = next((msg for msg in reversed(messages) if isinstance(msg, HumanMessage)), None)

        # Print the content of the last HumanMessage
        

        if self.debug:
            #messages= state["messages"]
            print(f"📊 [DEBUG] Last human message: {last_human_message.content}")
       
        # Compose a prompt for the evaluator LLM
        eval_prompt = (
            f"You are evaluating whether the response \"{last_llm_response}\" is acceptable as a final answer to the user's request \"{last_human_message.content}\".\n"
            f"Respond with exactly one word: 'acceptable' or 'not acceptable'.\n\n"
            #f"Conversation context: {state['messages']}"
        )

        print("llm response")
        evaluation = self.llm.invoke([{"role": "user", "content": eval_prompt}])
        if self.debug:
            print(f"[DEBUG] Evaluator LLM prompt: {eval_prompt}")
            print(f"[DEBUG] Evaluator LLM output: {evaluation.content}")  

        # Attach the evaluation to the state
        
        return {**state, "messages": state["messages"], "evaluation": evaluation.content.strip().lower()}


    def _is_acceptable(self, state: AgentState) -> str:
        """Returns 'acceptable' or 'not_acceptable' based on evaluator output."""
        evaluation = state.get("evaluation", "").strip().lower()
        if  evaluation == "acceptable":
            return "acceptable"
        else:
            return "not_acceptable"

    
    def chat(self, message: str, conversation_history: List[BaseMessage] = None) -> str:
        """
        Send a message to the chatbot and get a response.
        
        Args:
            message: The user's message
            conversation_history: Previous conversation messages
            
        Returns:
            The chatbot's response
        """
        if self.debug:
            print(f"\n💬 [DEBUG] ===== NEW CHAT SESSION =====")
            print(f"💬 [DEBUG] User message: {message}")
            print(f"💬 [DEBUG] Conversation history length: {len(conversation_history) if conversation_history else 0}")
            print(f"💬 [DEBUG] Conversations: {conversation_history}") 

        # Prepare the input
        messages = conversation_history or []
        messages.append(HumanMessage(content=message))
        
        inputs = {"messages": messages}

        if self.debug:
            print(f"💬 [DEBUG] Final input message: {inputs}")
        
        if self.debug:
            print(f"💬 [DEBUG] Total messages to process: {len(messages)}")            
            print(f"🚀 [DEBUG] Starting LangGraph workflow execution...")
        
        # Run the graph
        result = self.graph.invoke(inputs)

        if self.debug:
            print(f"✅ [DEBUG] LangGraph workflow completed")
            print(f"✅ [DEBUG] Total messages in result: {len(result['messages'])}")
            print(f"🔍 [DEBUG] All messages in result:")
            # for i, msg in enumerate(result['messages']):
            #     print(f"   {i}: {type(msg).__name__} - {msg.content[:100]}...")
        
        # Return the last AI message
        ai_messages = [msg for msg in result["messages"] if isinstance(msg, AIMessage)]
        
        # if self.debug:
        #     print(f"🔍 [DEBUG] Found {len(ai_messages)} AI messages")
        #     for i, msg in enumerate(ai_messages):
        #         print(f"   AI Message {i}: {msg.content[:100]}...")
        
        if ai_messages:
            final_response = ai_messages[-1].content
            if self.debug:
                print(f"🎯 [DEBUG] Final AI response: {final_response}")
                print(f"💬 [DEBUG] ===== CHAT SESSION END =====\n")
            return final_response
        else:
            if self.debug:
                print(f"❌ [DEBUG] No AI messages found in result")
                print(f"🔍 [DEBUG] Message types in result: {[type(msg).__name__ for msg in result['messages']]}")
                print(f"💬 [DEBUG] ===== CHAT SESSION END =====\n")
            return "I'm sorry, I couldn't generate a response."
    
    def stream_chat(self, message: str, conversation_history: List[BaseMessage] = None):
        """
        Stream the chatbot's response.
        
        Args:
            message: The user's message
            conversation_history: Previous conversation messages
            
        Yields:
            Streaming response chunks
        """
        messages = conversation_history or []
        messages.append(HumanMessage(content=message))
        
        inputs = {"messages": messages}
        
        for chunk in self.graph.stream(inputs):
            if "messages" in chunk and chunk["messages"]:
                last_message = chunk["messages"][-1]
                if isinstance(last_message, AIMessage):
                    yield last_message.content

# Convenience function to create a simple chatbot
def create_simple_chatbot(debug: bool = True) -> LangGraphChatbot:
    """Create a simple chatbot instance with optional debugging."""
    return LangGraphChatbot(debug=debug)

# Example usage
if __name__ == "__main__":
    chatbot = create_simple_chatbot()
    
    print("LangGraph Chatbot initialized!")
    #print("Available tools:", [tool.name for tool in AVAILABLE_TOOLS])
    print("\nType 'quit' to exit\n")
    
    conversation_history = []
    
    while True:
        user_input = input("You: ")
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("Goodbye!")
            break
        
        try:
            response = chatbot.chat(user_input, conversation_history)
            print(f"Bot: {response}\n")
            
            # Update conversation history
            conversation_history.extend([
                HumanMessage(content=user_input),
                AIMessage(content=response)
            ])
            
        except Exception as e:
            print(f"Error: {e}")
            print("Please make sure you have set your OPENAI_API_KEY in the .env file\n")
    
   
