cd C:\code\DarkNoc\poc\langgraph\venv\Scripts
& "C:\code\DarkNoc\poc\langgraph\venv\Scripts\Activate.ps1"
streamlit run app.py

