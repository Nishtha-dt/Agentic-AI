from langgraph.graph import StateGraph
from langchain_core.runnables import RunnableLambda
from pydantic import BaseModel

# Define input and output schema
class InputState(BaseModel):
    name: str

class OutputState(BaseModel):
    message: str

# Create the graph with schema
graph = StateGraph(input=InputState, output=OutputState)

# Fix: Use attribute access
graph.add_node("greet", RunnableLambda(lambda state: {"message": f"Hello, {state.name}!"}))

graph.set_entry_point("greet")
app = graph.compile()

# Run the graph
result = app.invoke({"name": "Satish"})
print(result)  # Output: {'message': 'Hello, Satish!'}



from langchain_core.runnables import RunnableLambda

step1 = RunnableLambda(lambda state: {"text": state.input})
step2 = RunnableLambda(lambda state: {"text": state.text.upper()})
step3 = RunnableLambda(lambda state: {"response": f"Processed: {state.text}"})


