"""
Memory demonstration with LangGraph chatbot.
This shows how the chatbot maintains conversation context.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chatbot import LangGraphChatbot
from langchain.schema import HumanMessage, AIMessage

def main():
    print("=== LangGraph Memory Demonstration ===")
    print("This example shows how the chatbot remembers previous conversation context.")
    print("\nTry having a conversation where you refer to previous messages:")
    print("- 'My name is John'")
    print("- 'What's my name?' (should remember John)")
    print("- 'I like pizza'")
    print("- 'What do I like to eat?' (should remember pizza)")
    print("\nType 'quit' to exit\n")
    
    # Create chatbot instance
    try:
        chatbot = LangGraphChatbot()
        print("✅ Chatbot initialized successfully!")
    except Exception as e:
        print(f"❌ Failed to initialize chatbot: {e}")
        print("Make sure you have set your OPENAI_API_KEY in the .env file")
        return
    
    conversation_history = []
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("👋 Goodbye!")
            break
        
        if user_input.lower() == 'history':
            print("\n📚 Conversation History:")
            for i, msg in enumerate(conversation_history):
                role = "User" if isinstance(msg, HumanMessage) else "Bot"
                print(f"{i+1}. {role}: {msg.content}")
            continue
        
        try:
            # Get response from chatbot with full conversation history
            response = chatbot.chat(user_input, conversation_history)
            print(f"🤖 Bot: {response}")
            
            # Update conversation history
            conversation_history.extend([
                HumanMessage(content=user_input),
                AIMessage(content=response)
            ])
            
            # Show memory info
            print(f"📝 Memory: {len(conversation_history)} messages in history")
            
        except Exception as e:
            print(f"❌ Error: {e}")

def demonstrate_memory_scenarios():
    """Run predefined scenarios to show memory capabilities."""
    print("\n=== Automated Memory Scenarios ===")
    
    try:
        chatbot = LangGraphChatbot()
        conversation_history = []
        
        scenarios = [
            ("My favorite color is blue", "Setting preference"),
            ("I work as a software engineer", "Setting profession"),
            ("What's my favorite color?", "Testing color memory"),
            ("What do I do for work?", "Testing profession memory"),
            ("Do I like the color red?", "Testing color preference"),
        ]
        
        for message, description in scenarios:
            print(f"\n📝 {description}")
            print(f"User: {message}")
            
            response = chatbot.chat(message, conversation_history)
            print(f"Bot: {response}")
            
            # Update history
            conversation_history.extend([
                HumanMessage(content=message),
                AIMessage(content=response)
            ])
            
            input("Press Enter to continue...")
            
    except Exception as e:
        print(f"❌ Demonstration failed: {e}")

if __name__ == "__main__":
    choice = input("Choose mode: (1) Interactive memory test, (2) Automated scenarios: ")
    
    if choice == "2":
        demonstrate_memory_scenarios()
    else:
        main()
