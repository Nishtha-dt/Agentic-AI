"""
Tool usage example with LangGraph chatbot.
This demonstrates how the chatbot can use various tools.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chatbot import LangGraphChatbot
from tools import AVAILABLE_TOOLS
from langchain.schema import HumanMessage, AIMessage

def main():
    print("=== LangGraph Tool Usage Example ===")
    print("This example demonstrates tool integration capabilities.")
    print(f"Available tools: {[tool.name for tool in AVAILABLE_TOOLS]}")
    print("\nTry asking:")
    print("- 'What is 25 * 4?'")
    print("- 'What's the weather in London?'")
    print("- 'Search for information about machine learning'")
    print("\nType 'quit' to exit\n")
    
    # Create chatbot with tools
    try:
        chatbot = LangGraphChatbot(tools=AVAILABLE_TOOLS)
        print("✅ Chatbot with tools initialized successfully!")
    except Exception as e:
        print(f"❌ Failed to initialize chatbot: {e}")
        print("Make sure you have set your OPENAI_API_KEY in the .env file")
        return
    
    conversation_history = []
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("👋 Goodbye!")
            break
        
        try:
            # Get response from chatbot
            print("🤖 Bot: ", end="", flush=True)
            response = chatbot.chat(user_input, conversation_history)
            print(response)
            
            # Update conversation history
            conversation_history.extend([
                HumanMessage(content=user_input),
                AIMessage(content=response)
            ])
            
        except Exception as e:
            print(f"❌ Error: {e}")

def demo_tool_calls():
    """Demonstrate specific tool calls."""
    print("\n=== Tool Demonstration ===")
    
    try:
        chatbot = LangGraphChatbot(tools=AVAILABLE_TOOLS)
        
        # Test cases
        test_cases = [
            "Calculate 123 + 456",
            "What's the weather like in New York?",
            "Search for information about Python programming"
        ]
        
        for test_case in test_cases:
            print(f"\n📝 Test: {test_case}")
            response = chatbot.chat(test_case)
            print(f"🤖 Response: {response}")
            
    except Exception as e:
        print(f"❌ Demo failed: {e}")

if __name__ == "__main__":
    choice = input("Choose mode: (1) Interactive chat, (2) Tool demo: ")
    
    if choice == "2":
        demo_tool_calls()
    else:
        main()
