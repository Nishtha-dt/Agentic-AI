"""
Advanced LangGraph patterns and workflows.
This demonstrates more complex conversation flows and state management.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import TypedDict, List, Dict, Any, Annotated
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, BaseMessage
import operator
from config import Config

# Extended state for advanced patterns
class AdvancedAgentState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
    user_intent: str
    conversation_mode: str
    context: Dict[str, Any]
    step_count: int

class AdvancedChatbot:
    """Advanced chatbot with multiple conversation modes and complex state management."""
    
    def __init__(self):
        self.llm = ChatOpenAI(
            model=Config.DEFAULT_MODEL,
            temperature=Config.TEMPERATURE,
            openai_api_key=Config.OPENAI_API_KEY
        )
        self.graph = self._create_advanced_graph()
    
    def _create_advanced_graph(self) -> StateGraph:
        """Create an advanced workflow with multiple paths."""
        workflow = StateGraph(AdvancedAgentState)
        
        # Add nodes for different conversation modes
        workflow.add_node("intent_analyzer", self._analyze_intent)
        workflow.add_node("casual_chat", self._casual_chat)
        workflow.add_node("problem_solver", self._problem_solver)
        workflow.add_node("information_provider", self._information_provider)
        workflow.add_node("conversation_manager", self._manage_conversation)
        
        # Set entry point
        workflow.set_entry_point("intent_analyzer")
        
        # Add conditional routing based on intent
        workflow.add_conditional_edges(
            "intent_analyzer",
            self._route_conversation,
            {
                "casual": "casual_chat",
                "problem": "problem_solver",
                "information": "information_provider",
                "manage": "conversation_manager"
            }
        )
        
        # All paths lead to conversation manager
        workflow.add_edge("casual_chat", "conversation_manager")
        workflow.add_edge("problem_solver", "conversation_manager")
        workflow.add_edge("information_provider", "conversation_manager")
        
        # End or continue based on conversation manager decision
        workflow.add_conditional_edges(
            "conversation_manager",
            self._should_continue_conversation,
            {
                "continue": "intent_analyzer",
                "end": END
            }
        )
        
        return workflow.compile()
    
    def _analyze_intent(self, state: AdvancedAgentState) -> Dict[str, Any]:
        """Analyze user intent from the latest message."""
        latest_message = state["messages"][-1].content.lower()
        
        # Simple intent classification
        if any(word in latest_message for word in ["hello", "hi", "how are you", "good morning"]):
            intent = "casual"
        elif any(word in latest_message for word in ["help", "problem", "issue", "error", "fix"]):
            intent = "problem"
        elif any(word in latest_message for word in ["what", "how", "when", "where", "why", "explain"]):
            intent = "information"
        else:
            intent = "casual"
        
        return {
            "user_intent": intent,
            "step_count": state.get("step_count", 0) + 1
        }
    
    def _casual_chat(self, state: AdvancedAgentState) -> Dict[str, Any]:
        """Handle casual conversation."""
        prompt = f"""You are having a casual, friendly conversation. 
        The user said: {state['messages'][-1].content}
        Respond in a warm, conversational manner."""
        
        response = self.llm.invoke([HumanMessage(content=prompt)])
        
        return {
            "messages": [AIMessage(content=response.content)],
            "conversation_mode": "casual"
        }
    
    def _problem_solver(self, state: AdvancedAgentState) -> Dict[str, Any]:
        """Handle problem-solving conversations."""
        prompt = f"""You are a helpful problem solver. 
        The user has a problem: {state['messages'][-1].content}
        Provide a structured, helpful response with actionable steps."""
        
        response = self.llm.invoke([HumanMessage(content=prompt)])
        
        return {
            "messages": [AIMessage(content=response.content)],
            "conversation_mode": "problem_solving"
        }
    
    def _information_provider(self, state: AdvancedAgentState) -> Dict[str, Any]:
        """Handle information requests."""
        prompt = f"""You are an knowledgeable information provider. 
        The user wants to know: {state['messages'][-1].content}
        Provide accurate, detailed, and well-structured information."""
        
        response = self.llm.invoke([HumanMessage(content=prompt)])
        
        return {
            "messages": [AIMessage(content=response.content)],
            "conversation_mode": "information"
        }
    
    def _manage_conversation(self, state: AdvancedAgentState) -> Dict[str, Any]:
        """Manage the overall conversation flow."""
        context = {
            "total_exchanges": state.get("step_count", 0),
            "current_mode": state.get("conversation_mode", "unknown"),
            "user_intent": state.get("user_intent", "unknown")
        }
        
        return {"context": context}
    
    def _route_conversation(self, state: AdvancedAgentState) -> str:
        """Route conversation based on analyzed intent."""
        return state.get("user_intent", "casual")
    
    def _should_continue_conversation(self, state: AdvancedAgentState) -> str:
        """Determine if conversation should continue."""
        # For this demo, we'll always end after one exchange
        return "end"
    
    def chat(self, message: str) -> Dict[str, Any]:
        """Chat with advanced state management."""
        initial_state = {
            "messages": [HumanMessage(content=message)],
            "user_intent": "",
            "conversation_mode": "",
            "context": {},
            "step_count": 0
        }
        
        result = self.graph.invoke(initial_state)
        
        # Extract the AI response
        ai_messages = [msg for msg in result["messages"] if isinstance(msg, AIMessage)]
        response_content = ai_messages[-1].content if ai_messages else "No response generated"
        
        return {
            "response": response_content,
            "intent": result.get("user_intent", "unknown"),
            "mode": result.get("conversation_mode", "unknown"),
            "context": result.get("context", {})
        }

def main():
    print("=== Advanced LangGraph Patterns Demo ===")
    print("This demonstrates advanced conversation routing and state management.")
    print("The bot will analyze your intent and respond accordingly.")
    print("\nTry different types of messages:")
    print("- Casual: 'Hello, how are you?'")
    print("- Problem: 'I need help with my code'")
    print("- Information: 'What is machine learning?'")
    print("\nType 'quit' to exit\n")
    
    try:
        chatbot = AdvancedChatbot()
        print("✅ Advanced chatbot initialized!")
    except Exception as e:
        print(f"❌ Failed to initialize: {e}")
        return
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("👋 Goodbye!")
            break
        
        try:
            result = chatbot.chat(user_input)
            
            print(f"🤖 Bot: {result['response']}")
            print(f"📊 Analysis - Intent: {result['intent']}, Mode: {result['mode']}")
            
            if result['context']:
                print(f"📈 Context: {result['context']}")
            
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
