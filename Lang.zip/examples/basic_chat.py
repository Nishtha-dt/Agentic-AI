"""
Basic chat example with LangGraph chatbot.
This demonstrates simple conversational interaction.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chatbot import create_simple_chatbot
from langchain.schema import HumanMessage, AIMessage

def main():
    print("=== LangGraph Basic Chat Example ===")
    print("This example demonstrates basic conversational capabilities.")
    print("Type 'quit' to exit\n")
    
    # Create chatbot instance
    try:
        chatbot = create_simple_chatbot()
        print("✅ Chatbot initialized successfully!")
    except Exception as e:
        print(f"❌ Failed to initialize chatbot: {e}")
        print("Make sure you have set your OPENAI_API_KEY in the .env file")
        return
    
    conversation_history = []
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("👋 Goodbye!")
            break
        
        try:
            # Get response from chatbot
            response = chatbot.chat(user_input, conversation_history)
            print(f"🤖 Bot: {response}")
            
            # Update conversation history
            conversation_history.extend([
                HumanMessage(content=user_input),
                AIMessage(content=response)
            ])
            
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
