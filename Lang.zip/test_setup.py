"""
Test script to verify the LangGraph chatbot setup.
Run this after setup to ensure everything is working correctly.
"""

import os
import sys
from pathlib import Path

def test_imports():
    """Test if all required packages can be imported."""
    print("🧪 Testing imports...")
    
    try:
        import langchain
        print("✅ langchain imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import langchain: {e}")
        return False
    
    try:
        import langgraph
        print("✅ langgraph imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import langgraph: {e}")
        return False
    
    try:
        from langchain_openai import ChatOpenAI
        print("✅ langchain_openai imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import langchain_openai: {e}")
        return False
    
    try:
        import streamlit
        print("✅ streamlit imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import streamlit: {e}")
        return False
    
    return True

def test_env_setup():
    """Test if environment is set up correctly."""
    print("\n🔧 Testing environment setup...")
    
    # Check if .env file exists
    env_file = Path(".env")
    if not env_file.exists():
        print("❌ .env file not found")
        return False
    else:
        print("✅ .env file found")
    
    # Load environment variables
    from dotenv import load_dotenv
    load_dotenv()
    
    # Check for OpenAI API key
    openai_key = os.getenv("OPENAI_API_KEY")
    if not openai_key or openai_key == "your_openai_api_key_here":
        print("❌ OPENAI_API_KEY not set or using placeholder value")
        print("   Please edit the .env file and add your actual OpenAI API key")
        return False
    else:
        print("✅ OPENAI_API_KEY is set")
    
    return True

def test_tools():
    """Test if tools are working correctly."""
    print("\n🛠️  Testing tools...")
    
    try:
        from tools import AVAILABLE_TOOLS, calculator, get_weather
        print(f"✅ Found {len(AVAILABLE_TOOLS)} tools")
        
        # Test calculator
        result = calculator.invoke("2 + 2")
        if "4" in str(result):
            print("✅ Calculator tool working")
        else:
            print(f"❌ Calculator tool issue: {result}")
            return False
        
        # Test weather tool
        result = get_weather.invoke("New York")
        if "New York" in str(result):
            print("✅ Weather tool working")
        else:
            print(f"❌ Weather tool issue: {result}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Error testing tools: {e}")
        return False

def test_simple_chatbot():
    """Test the simple chatbot implementation."""
    print("\n🤖 Testing simple chatbot...")
    
    try:
        from simple_chatbot import create_simple_chatbot
        chatbot = create_simple_chatbot()
        
        # Test basic response
        response = chatbot.chat("Hello")
        if response and len(response) > 0:
            print("✅ Simple chatbot responding")
            print(f"   Sample response: {response[:100]}...")
        else:
            print("❌ Simple chatbot not responding properly")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Error testing simple chatbot: {e}")
        return False

def test_langgraph_chatbot():
    """Test the LangGraph chatbot implementation."""
    print("\n🔄 Testing LangGraph chatbot...")
    
    try:
        from chatbot import create_simple_chatbot
        chatbot = create_simple_chatbot()
        
        # Test basic response
        response = chatbot.chat("Hello")
        if response and len(response) > 0:
            print("✅ LangGraph chatbot responding")
            print(f"   Sample response: {response[:100]}...")
        else:
            print("❌ LangGraph chatbot not responding properly")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Error testing LangGraph chatbot: {e}")
        print("   This might be expected if LangGraph imports are not working yet")
        return True  # Don't fail the test for this

def main():
    """Run all tests."""
    print("🧪 LangGraph Chatbot POC - Test Suite")
    print("=" * 50)
    
    tests = [
        ("Import Test", test_imports),
        ("Environment Test", test_env_setup),
        ("Tools Test", test_tools),
        ("Simple Chatbot Test", test_simple_chatbot),
        ("LangGraph Chatbot Test", test_langgraph_chatbot),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n--- {test_name} ---")
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name} PASSED")
            else:
                print(f"❌ {test_name} FAILED")
        except Exception as e:
            print(f"❌ {test_name} ERROR: {e}")
    
    print(f"\n{'='*50}")
    print(f"Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Your setup is ready.")
        print("\nNext steps:")
        print("- Run: python examples/basic_chat.py")
        print("- Or: streamlit run app.py")
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
        print("Make sure you've run the setup script and configured your .env file.")

if __name__ == "__main__":
    main()
